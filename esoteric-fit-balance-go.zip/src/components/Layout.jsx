import React from "react";
import { Link, useLocation, Outlet } from "react-router-dom";
import { Home, Calculator, LayoutDashboard, History, User, Moon, Sun } from "lucide-react";
import { useTheme } from "@/components/ThemeProvider";

const navItems = [
  { to: "/", label: "Home", icon: Home },
  { to: "/calculator", label: "Calculate", icon: Calculator },
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/history", label: "History", icon: History },
  { to: "/profile", label: "Profile", icon: User },
];

export default function Layout() {
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen gradient-bg flex flex-col">
      <div className="flex-1 w-full max-w-md mx-auto px-4 pb-28 pt-4">
        <Outlet />
      </div>

      {/* Theme toggle - floating */}
      <button
        onClick={toggleTheme}
        className="fixed top-4 right-4 z-50 p-2.5 rounded-full glass-card shadow-md hover:scale-105 transition-transform border border-white/20"
        aria-label="Toggle dark mode"
      >
        {theme === "light" ? (
          <Moon className="w-5 h-5 text-slate-700" />
        ) : (
          <Sun className="w-5 h-5 text-amber-300" />
        )}
      </button>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40">
        <div className="max-w-md mx-auto px-3 pb-3">
          <div className="glass-card rounded-2xl shadow-lg border border-white/20 flex items-center justify-around px-1 py-1.5">
            {navItems.map(({ to, label, icon: Icon }) => {
              const active = location.pathname === to;
              return (
                <Link
                  key={to}
                  to={to}
                  className="flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all duration-200"
                >
                  <div
                    className={`p-1.5 rounded-xl transition-all duration-200 ${
                      active
                        ? "bg-gradient-to-br from-teal-500 to-emerald-500 text-white shadow-md scale-105"
                        : "text-slate-400 dark:text-slate-500"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span
                    className={`text-[10px] font-medium transition-colors ${
                      active ? "text-teal-600 dark:text-teal-400" : "text-slate-400 dark:text-slate-500"
                    }`}
                  >
                    {label}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}