import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Trash2, Calculator, TrendingDown } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getBMICategory } from "@/lib/bmiUtils";
import { useToast } from "@/components/ui/use-toast";

export default function History() {
  const { toast } = useToast();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.BmiRecord.list("-created_date", 50);
      setRecords(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleDelete = async (id) => {
    try {
      await base44.entities.BmiRecord.delete(id);
      setRecords((prev) => prev.filter((r) => r.id !== id));
      toast({ title: "Deleted", description: "Record removed from history." });
    } catch (err) {
      toast({ title: "Error", description: "Could not delete record.", variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5 pt-8">
      <div className="space-y-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">BMI History</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          {records.length > 0 ? `${records.length} saved record${records.length > 1 ? "s" : ""}` : "Track your improvement over time"}
        </p>
      </div>

      {records.length === 0 ? (
        <div className="glass-card rounded-2xl p-8 border border-white/20 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto">
            <TrendingDown className="w-8 h-8 text-emerald-500" />
          </div>
          <div className="space-y-1">
            <p className="font-semibold text-slate-700 dark:text-slate-200">No history yet</p>
            <p className="text-sm text-slate-400">Save your first BMI calculation to see it here</p>
          </div>
          <Link
            to="/calculator"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-medium text-sm"
          >
            <Calculator className="w-4 h-4" /> Calculate BMI
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {records.map((r, idx) => {
            const cat = getBMICategory(r.bmi_value);
            const prev = records[idx + 1];
            const diff = prev ? r.bmi_value - prev.bmi_value : 0;
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="glass-card rounded-2xl p-4 border border-white/20 flex items-center gap-4"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${cat.gradient} flex flex-col items-center justify-center shadow-md`}>
                  <span className="text-lg font-bold text-white leading-none">{r.bmi_value.toFixed(1)}</span>
                </div>
                <div className="flex-1 space-y-0.5">
                  <p className={`text-sm font-semibold ${cat.textColor}`}>{cat.label}</p>
                  <p className="text-xs text-slate-400">
                    {r.weight} kg · {r.height} cm
                    {r.age ? ` · ${r.age} yrs` : ""}
                  </p>
                  <p className="text-xs text-slate-400">
                    {new Date(r.created_date).toLocaleDateString("en", { year: "numeric", month: "short", day: "numeric" })}
                  </p>
                  {prev && (
                    <p className={`text-xs font-medium ${diff <= 0 ? "text-emerald-500" : "text-amber-500"}`}>
                      {diff > 0 ? "↑" : "↓"} {Math.abs(diff).toFixed(1)} from previous
                    </p>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(r.id)}
                  className="p-2 rounded-lg text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors"
                  aria-label="Delete record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}