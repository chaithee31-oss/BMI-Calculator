import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Calculator, User, Ruler, Weight, ArrowLeft, Loader2 } from "lucide-react";
import { calculateBMI, ftInToCm, lbsToKg } from "@/lib/bmiUtils";

export default function CalculatorPage() {
  const navigate = useNavigate();
  const [unitSystem, setUnitSystem] = useState("metric");
  const [gender, setGender] = useState("male");
  const [age, setAge] = useState("");
  const [heightCm, setHeightCm] = useState("");
  const [weightKg, setWeightKg] = useState("");
  const [feet, setFeet] = useState("");
  const [inches, setInches] = useState("");
  const [weightLbs, setWeightLbs] = useState("");
  const [errors, setErrors] = useState({});
  const [calculating, setCalculating] = useState(false);

  const handleCalculate = () => {
    const errs = {};
    if (!age || age < 2 || age > 120) errs.age = "Enter a valid age (2–120)";
    if (unitSystem === "metric") {
      if (!heightCm || heightCm < 50 || heightCm > 300) errs.height = "Enter height between 50–300 cm";
      if (!weightKg || weightKg < 20 || weightKg > 500) errs.weight = "Enter weight between 20–500 kg";
    } else {
      if (!feet || feet < 1 || feet > 9) errs.feet = "Enter feet (1–9)";
      if (inches === "" || inches < 0 || inches > 11) errs.inches = "Enter inches (0–11)";
      if (!weightLbs || weightLbs < 44 || weightLbs > 1100) errs.weight = "Enter weight between 44–1100 lbs";
    }

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setCalculating(true);

    setTimeout(() => {
      let finalHeightCm, finalWeightKg;
      if (unitSystem === "metric") {
        finalHeightCm = parseFloat(heightCm);
        finalWeightKg = parseFloat(weightKg);
      } else {
        finalHeightCm = ftInToCm(parseFloat(feet), parseFloat(inches));
        finalWeightKg = lbsToKg(parseFloat(weightLbs));
      }
      const bmi = calculateBMI(finalWeightKg, finalHeightCm);
      navigate("/result", {
        state: {
          bmi: Math.round(bmi * 10) / 10,
          height: Math.round(finalHeightCm * 10) / 10,
          weight: Math.round(finalWeightKg * 10) / 10,
          age: parseInt(age),
          gender,
        },
      });
    }, 1200);
  };

  const inputClass =
    "w-full px-4 py-3 rounded-xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition-all text-sm";

  return (
    <div className="space-y-5 pt-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      <div className="space-y-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">BMI Calculator</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Enter your details to calculate your BMI</p>
      </div>

      {/* Unit toggle */}
      <div className="glass-card rounded-2xl p-1.5 border border-white/20 flex">
        {["metric", "imperial"].map((unit) => (
          <button
            key={unit}
            onClick={() => {
              setUnitSystem(unit);
              setErrors({});
            }}
            className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
              unitSystem === unit
                ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white shadow-md"
                : "text-slate-500 dark:text-slate-400"
            }`}
          >
            {unit === "metric" ? "cm / kg" : "ft / lbs"}
          </button>
        ))}
      </div>

      {/* Gender */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="glass-card rounded-2xl p-5 border border-white/20 space-y-3"
      >
        <label className="text-sm font-semibold text-slate-700 dark:text-slate-200">Gender</label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setGender("male")}
            className={`flex flex-col items-center gap-2 py-4 rounded-xl border-2 transition-all duration-200 ${
              gender === "male"
                ? "border-blue-400 bg-blue-50 dark:bg-blue-900/30"
                : "border-slate-200 dark:border-slate-700"
            }`}
          >
            <span className={`text-2xl ${gender === "male" ? "opacity-100" : "opacity-40"}`}>♂</span>
            <span className={`text-sm font-medium ${gender === "male" ? "text-blue-600 dark:text-blue-400" : "text-slate-500"}`}>
              Male
            </span>
          </button>
          <button
            onClick={() => setGender("female")}
            className={`flex flex-col items-center gap-2 py-4 rounded-xl border-2 transition-all duration-200 ${
              gender === "female"
                ? "border-pink-400 bg-pink-50 dark:bg-pink-900/30"
                : "border-slate-200 dark:border-slate-700"
            }`}
          >
            <span className={`text-2xl ${gender === "female" ? "opacity-100" : "opacity-40"}`}>♀</span>
            <span className={`text-sm font-medium ${gender === "female" ? "text-pink-600 dark:text-pink-400" : "text-slate-500"}`}>
              Female
            </span>
          </button>
        </div>
      </motion.div>

      {/* Age */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.05 }}
        className="glass-card rounded-2xl p-5 border border-white/20 space-y-2"
      >
        <label className="text-sm font-semibold text-slate-700 dark:text-slate-200">Age</label>
        <input
          type="number"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          placeholder="Enter your age"
          className={inputClass}
        />
        {errors.age && <p className="text-xs text-rose-500">{errors.age}</p>}
      </motion.div>

      {/* Height & Weight */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="glass-card rounded-2xl p-5 border border-white/20 space-y-4"
      >
        {unitSystem === "metric" ? (
          <>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Ruler className="w-4 h-4" /> Height (cm)
              </label>
              <input
                type="number"
                value={heightCm}
                onChange={(e) => setHeightCm(e.target.value)}
                placeholder="e.g. 175"
                className={inputClass}
              />
              {errors.height && <p className="text-xs text-rose-500">{errors.height}</p>}
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Weight className="w-4 h-4" /> Weight (kg)
              </label>
              <input
                type="number"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
                placeholder="e.g. 70"
                className={inputClass}
              />
              {errors.weight && <p className="text-xs text-rose-500">{errors.weight}</p>}
            </div>
          </>
        ) : (
          <>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Ruler className="w-4 h-4" /> Height
              </label>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="number"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)}
                  placeholder="ft"
                  className={inputClass}
                />
                <input
                  type="number"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)}
                  placeholder="in"
                  className={inputClass}
                />
              </div>
              {errors.feet && <p className="text-xs text-rose-500">{errors.feet}</p>}
              {errors.inches && <p className="text-xs text-rose-500">{errors.inches}</p>}
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Weight className="w-4 h-4" /> Weight (lbs)
              </label>
              <input
                type="number"
                value={weightLbs}
                onChange={(e) => setWeightLbs(e.target.value)}
                placeholder="e.g. 154"
                className={inputClass}
              />
              {errors.weight && <p className="text-xs text-rose-500">{errors.weight}</p>}
            </div>
          </>
        )}
      </motion.div>

      {/* Calculate button */}
      <button
        onClick={handleCalculate}
        disabled={calculating}
        className="w-full py-4 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-200/40 hover:shadow-xl hover:scale-[1.02] transition-all duration-200 disabled:opacity-70 disabled:scale-100 flex items-center justify-center gap-2"
      >
        {calculating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Calculating...
          </>
        ) : (
          <>
            <Calculator className="w-5 h-5" />
            Calculate BMI
          </>
        )}
      </button>
    </div>
  );
}