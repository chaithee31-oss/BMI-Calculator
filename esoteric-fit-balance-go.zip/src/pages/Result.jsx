import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Save, Home as HomeIcon, Check, Info, Lightbulb } from "lucide-react";
import { getBMICategory, getBmiPosition } from "@/lib/bmiUtils";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function Result() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  const data = location.state;

  if (!data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <p className="text-slate-500 text-sm">No calculation found. Please calculate your BMI first.</p>
        <button
          onClick={() => navigate("/calculator")}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-medium text-sm"
        >
          Go to Calculator
        </button>
      </div>
    );
  }

  const { bmi, height, weight, age, gender } = data;
  const category = getBMICategory(bmi);
  const position = getBmiPosition(bmi);

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.entities.BmiRecord.create({
        bmi_value: bmi,
        category: category.label,
        weight,
        height,
        age,
        gender,
      });
      setSaved(true);
      toast({ title: "Saved!", description: "Your BMI result has been saved to history." });
    } catch (err) {
      toast({ title: "Error", description: "Could not save result. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5 pt-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, type: "spring" }}
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${category.gradient} p-8 shadow-xl text-center`}
      >
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full" />
        <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-white/10 rounded-full" />
        <div className="relative space-y-2">
          <p className="text-white/80 text-xs font-semibold uppercase tracking-wider">Your BMI</p>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-6xl font-bold text-white"
          >
            {bmi.toFixed(1)}
          </motion.div>
          <div className="inline-block px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-sm">
            <span className="text-white font-semibold text-sm">{category.label}</span>
          </div>
        </div>
      </motion.div>

      {/* Progress bar */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card rounded-2xl p-5 border border-white/20 space-y-3"
      >
        <div className="flex items-center justify-between text-[10px] font-medium text-slate-400">
          <span>15</span>
          <span>18.5</span>
          <span>25</span>
          <span>30</span>
          <span>40</span>
        </div>
        <div className="relative h-3 rounded-full overflow-hidden bg-gradient-to-r from-sky-400 via-emerald-400 to-rose-400">
          <motion.div
            initial={{ left: "0%" }}
            animate={{ left: `${position}%` }}
            transition={{ delay: 0.5, type: "spring", stiffness: 60 }}
            className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-white border-2 border-slate-300 shadow-lg"
          />
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 font-medium">
          <span className="text-sky-500">Under</span>
          <span className="text-emerald-500">Normal</span>
          <span className="text-amber-500">Over</span>
          <span className="text-rose-500">Obese</span>
        </div>
      </motion.div>

      {/* Stats summary */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-3 gap-3"
      >
        {[
          { label: "Weight", value: `${weight} kg` },
          { label: "Height", value: `${height} cm` },
          { label: "Age", value: `${age} yrs` },
        ].map((stat) => (
          <div key={stat.label} className="glass-card rounded-xl p-3 border border-white/20 text-center">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">{stat.label}</p>
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mt-1">{stat.value}</p>
          </div>
        ))}
      </motion.div>

      {/* Explanation */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className={`rounded-2xl p-5 border ${category.bgColor} border-white/20 space-y-2`}
      >
        <div className="flex items-center gap-2">
          <Info className={`w-4 h-4 ${category.textColor}`} />
          <h3 className={`font-semibold text-sm ${category.textColor}`}>About Your Result</h3>
        </div>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          Your BMI is <strong>{bmi.toFixed(1)}</strong>. You are in the <strong>{category.label}</strong> category.
        </p>
      </motion.div>

      {/* Suggestions */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="glass-card rounded-2xl p-5 border border-white/20 space-y-2"
      >
        <div className="flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-200">Personalized Suggestions</h3>
        </div>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{category.suggestion}</p>
      </motion.div>

      {/* Actions */}
      <div className="flex gap-3 pb-4">
        <button
          onClick={handleSave}
          disabled={saved || saving}
          className={`flex-1 py-4 rounded-2xl font-semibold text-sm shadow-lg transition-all duration-200 flex items-center justify-center gap-2 ${
            saved
              ? "bg-emerald-100 text-emerald-700"
              : "bg-gradient-to-r from-teal-500 to-emerald-500 text-white hover:shadow-xl hover:scale-[1.02]"
          }`}
        >
          {saved ? (
            <>
              <Check className="w-5 h-5" /> Saved
            </>
          ) : saving ? (
            "Saving..."
          ) : (
            <>
              <Save className="w-5 h-5" /> Save Result
            </>
          )}
        </button>
        <button
          onClick={() => navigate("/")}
          className="px-6 py-4 rounded-2xl glass-card border border-white/20 font-semibold text-sm text-slate-600 dark:text-slate-300 flex items-center gap-2"
        >
          <HomeIcon className="w-5 h-5" /> Home
        </button>
      </div>
    </div>
  );
}