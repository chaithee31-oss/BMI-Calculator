import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Salad, Dumbbell, Moon, Droplets, ChevronRight } from "lucide-react";
import { healthTips } from "@/lib/bmiUtils";

const iconMap = {
  Salad,
  Dumbbell,
  Moon,
  Droplets,
};

const categoryColors = {
  Nutrition: { bg: "from-green-400 to-emerald-500", soft: "bg-emerald-50 dark:bg-emerald-900/20", text: "text-emerald-600" },
  Exercise: { bg: "from-orange-400 to-amber-500", soft: "bg-amber-50 dark:bg-amber-900/20", text: "text-amber-600" },
  Sleep: { bg: "from-indigo-400 to-violet-500", soft: "bg-indigo-50 dark:bg-indigo-900/20", text: "text-indigo-600" },
  Hydration: { bg: "from-cyan-400 to-blue-500", soft: "bg-cyan-50 dark:bg-cyan-900/20", text: "text-cyan-600" },
};

export default function Tips() {
  const [activeCategory, setActiveCategory] = useState(healthTips[0].category);

  const active = healthTips.find((c) => c.category === activeCategory);
  const colors = categoryColors[activeCategory];

  return (
    <div className="space-y-5 pt-8">
      <div className="space-y-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Health Tips</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Wellness advice for everyday life</p>
      </div>

      {/* Category pills */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4">
        {healthTips.map((cat) => {
          const Icon = iconMap[cat.icon];
          const c = categoryColors[cat.category];
          const isActive = activeCategory === cat.category;
          return (
            <button
              key={cat.category}
              onClick={() => setActiveCategory(cat.category)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl whitespace-nowrap text-sm font-medium transition-all duration-200 ${
                isActive
                  ? `bg-gradient-to-r ${c.bg} text-white shadow-md`
                  : "glass-card border border-white/20 text-slate-500 dark:text-slate-400"
              }`}
            >
              <Icon className="w-4 h-4" />
              {cat.category}
            </button>
          );
        })}
      </div>

      {/* Active category header */}
      <motion.div
        key={activeCategory}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${colors.bg} p-6 shadow-xl`}
      >
        <div className="absolute -top-8 -right-8 w-32 h-32 bg-white/10 rounded-full" />
        <div className="relative flex items-center gap-3">
          {(() => {
            const Icon = iconMap[active.icon];
            return <Icon className="w-8 h-8 text-white" />;
          })()}
          <div>
            <h2 className="text-xl font-bold text-white">{active.category}</h2>
            <p className="text-white/80 text-xs">{active.tips.length} tips to explore</p>
          </div>
        </div>
      </motion.div>

      {/* Tips list */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeCategory}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="space-y-3"
        >
          {active.tips.map((tip, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.08 }}
              className={`glass-card rounded-2xl p-4 border border-white/20 flex items-start gap-3 ${colors.soft}`}
            >
              <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${colors.bg} flex items-center justify-center shrink-0 text-white text-sm font-bold`}>
                {idx + 1}
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed pt-1 flex-1">{tip}</p>
            </motion.div>
          ))}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}