import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { TrendingDown, TrendingUp, Activity, Target, Calculator, ArrowRight, Scale } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getBMICategory } from "@/lib/bmiUtils";

export default function Dashboard() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await base44.entities.BmiRecord.list("-created_date", 30);
        setRecords(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  const latest = records[0];
  const chartData = [...records].reverse().map((r, i) => ({
    name: `#${i + 1}`,
    bmi: Math.round(r.bmi_value * 10) / 10,
    weight: Math.round(r.weight * 10) / 10,
  }));

  const weightChange =
    records.length > 1 ? records[0].weight - records[records.length - 1].weight : 0;
  const bmiChange =
    records.length > 1 ? records[0].bmi_value - records[records.length - 1].bmi_value : 0;

  return (
    <div className="space-y-5 pt-8">
      <div className="space-y-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Dashboard</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Your health progress at a glance</p>
      </div>

      {records.length === 0 ? (
        <div className="glass-card rounded-2xl p-8 border border-white/20 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto">
            <Activity className="w-8 h-8 text-emerald-500" />
          </div>
          <div className="space-y-1">
            <p className="font-semibold text-slate-700 dark:text-slate-200">No data yet</p>
            <p className="text-sm text-slate-400">Calculate your BMI to start tracking progress</p>
          </div>
          <Link
            to="/calculator"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-medium text-sm"
          >
            <Calculator className="w-4 h-4" /> Calculate Now
          </Link>
        </div>
      ) : (
        <>
          {/* Current BMI */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-500 via-emerald-500 to-cyan-500 p-6 shadow-xl"
          >
            <div className="absolute -top-8 -right-8 w-32 h-32 bg-white/10 rounded-full" />
            <div className="relative space-y-1">
              <p className="text-white/80 text-xs font-semibold uppercase tracking-wider">Current BMI</p>
              <div className="flex items-end gap-3">
                <span className="text-5xl font-bold text-white">{latest.bmi_value.toFixed(1)}</span>
                <span className="text-white/90 text-sm font-medium pb-2">{getBMICategory(latest.bmi_value).label}</span>
              </div>
            </div>
          </motion.div>

          {/* Change indicators */}
          <div className="grid grid-cols-2 gap-3">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card rounded-2xl p-4 border border-white/20"
            >
              <div className="flex items-center gap-2 mb-1">
                {bmiChange <= 0 ? (
                  <TrendingDown className="w-4 h-4 text-emerald-500" />
                ) : (
                  <TrendingUp className="w-4 h-4 text-amber-500" />
                )}
                <span className="text-xs text-slate-400">BMI Change</span>
              </div>
              <p className={`text-lg font-bold ${bmiChange <= 0 ? "text-emerald-600" : "text-amber-600"}`}>
                {bmiChange > 0 ? "+" : ""}{bmiChange.toFixed(1)}
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="glass-card rounded-2xl p-4 border border-white/20"
            >
              <div className="flex items-center gap-2 mb-1">
                <Scale className="w-4 h-4 text-blue-500" />
                <span className="text-xs text-slate-400">Weight Change</span>
              </div>
              <p className={`text-lg font-bold ${weightChange <= 0 ? "text-emerald-600" : "text-amber-600"}`}>
                {weightChange > 0 ? "+" : ""}{weightChange.toFixed(1)} kg
              </p>
            </motion.div>
          </div>

          {/* BMI Trend Chart */}
          {records.length >= 2 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card rounded-2xl p-5 border border-white/20 space-y-3"
            >
              <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-emerald-500" /> BMI Trend
              </h3>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <defs>
                      <linearGradient id="bmiGradient" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#14b8a6" />
                        <stop offset="100%" stopColor="#10b981" />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.3} />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                    <YAxis domain={["auto", "auto"]} tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={32} />
                    <Tooltip
                      contentStyle={{
                        borderRadius: "12px",
                        border: "none",
                        boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
                        fontSize: "12px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="bmi"
                      stroke="url(#bmiGradient)"
                      strokeWidth={3}
                      dot={{ fill: "#10b981", r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}

          {/* Quick actions */}
          <div className="grid grid-cols-2 gap-3">
            <Link
              to="/calculator"
              className="glass-card rounded-2xl p-4 border border-white/20 hover:scale-[1.02] transition-transform flex items-center gap-2"
            >
              <Calculator className="w-5 h-5 text-emerald-500" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">New Calculation</span>
            </Link>
            <Link
              to="/history"
              className="glass-card rounded-2xl p-4 border border-white/20 hover:scale-[1.02] transition-transform flex items-center gap-2"
            >
              <Target className="w-5 h-5 text-blue-500" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">View History</span>
            </Link>
          </div>

          {/* Recent records */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-200">Recent Records</h3>
              <Link to="/history" className="text-xs text-emerald-500 flex items-center gap-1">
                See all <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            {records.slice(0, 3).map((r) => {
              const cat = getBMICategory(r.bmi_value);
              return (
                <div key={r.id} className="glass-card rounded-xl p-3 border border-white/20 flex items-center gap-3">
                  <div className={`w-2 h-12 rounded-full bg-gradient-to-b ${cat.gradient}`} />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{r.bmi_value.toFixed(1)} BMI</p>
                    <p className="text-xs text-slate-400">{r.weight} kg · {cat.label}</p>
                  </div>
                  <span className="text-xs text-slate-400">
                    {new Date(r.created_date).toLocaleDateString("en", { month: "short", day: "numeric" })}
                  </span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}