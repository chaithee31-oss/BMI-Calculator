import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { User, Save, Target, Ruler, Weight, Calendar, Edit3, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function Profile() {
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    full_name: "",
    age: "",
    gender: "male",
    height: "",
    weight: "",
    target_weight: "",
    health_goal: "",
  });

  useEffect(() => {
    const load = async () => {
      try {
        const data = await base44.entities.Profile.list("-created_date", 1);
        if (data.length > 0) {
          setProfile(data[0]);
          setForm({
            full_name: data[0].full_name || "",
            age: data[0].age || "",
            gender: data[0].gender || "male",
            height: data[0].height || "",
            weight: data[0].weight || "",
            target_weight: data[0].target_weight || "",
            health_goal: data[0].health_goal || "",
          });
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleSave = async () => {
    if (!form.full_name.trim()) {
      toast({ title: "Name required", description: "Please enter your name.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...form,
        age: form.age ? parseInt(form.age) : null,
        height: form.height ? parseFloat(form.height) : null,
        weight: form.weight ? parseFloat(form.weight) : null,
        target_weight: form.target_weight ? parseFloat(form.target_weight) : null,
      };
      if (profile) {
        const updated = await base44.entities.Profile.update(profile.id, payload);
        setProfile(updated);
      } else {
        const created = await base44.entities.Profile.create(payload);
        setProfile(created);
      }
      setEditing(false);
      toast({ title: "Profile saved!", description: "Your profile has been updated." });
    } catch (err) {
      toast({ title: "Error", description: "Could not save profile.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const inputClass =
    "w-full px-4 py-3 rounded-xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition-all text-sm";

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!editing && profile) {
    const goalDiff = profile.target_weight && profile.weight ? profile.target_weight - profile.weight : null;
    return (
      <div className="space-y-5 pt-8">
        <div className="space-y-1 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Profile</h1>
          <button
            onClick={() => setEditing(true)}
            className="flex items-center gap-1.5 text-sm text-emerald-500 hover:text-emerald-600 font-medium"
          >
            <Edit3 className="w-4 h-4" /> Edit
          </button>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl bg-gradient-to-br from-teal-500 via-emerald-500 to-cyan-500 p-6 shadow-xl text-center"
        >
          <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-3 text-3xl font-bold text-white">
            {profile.full_name?.charAt(0).toUpperCase()}
          </div>
          <h2 className="text-xl font-bold text-white">{profile.full_name}</h2>
          <p className="text-white/80 text-sm capitalize">{profile.gender || "—"}{profile.age ? ` · ${profile.age} years` : ""}</p>
        </motion.div>

        <div className="grid grid-cols-2 gap-3">
          <div className="glass-card rounded-2xl p-4 border border-white/20">
            <div className="flex items-center gap-2 mb-1">
              <Ruler className="w-4 h-4 text-blue-500" />
              <span className="text-xs text-slate-400">Height</span>
            </div>
            <p className="text-lg font-semibold text-slate-700 dark:text-slate-200">{profile.height ? `${profile.height} cm` : "—"}</p>
          </div>
          <div className="glass-card rounded-2xl p-4 border border-white/20">
            <div className="flex items-center gap-2 mb-1">
              <Weight className="w-4 h-4 text-emerald-500" />
              <span className="text-xs text-slate-400">Weight</span>
            </div>
            <p className="text-lg font-semibold text-slate-700 dark:text-slate-200">{profile.weight ? `${profile.weight} kg` : "—"}</p>
          </div>
        </div>

        {/* Goal */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card rounded-2xl p-5 border border-white/20 space-y-3"
        >
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-amber-500" />
            <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-200">Health Goal</h3>
          </div>
          {profile.target_weight && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Target Weight</span>
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{profile.target_weight} kg</span>
            </div>
          )}
          {goalDiff !== null && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">To Go</span>
              <span className={`text-sm font-semibold ${goalDiff <= 0 ? "text-emerald-600" : "text-amber-600"}`}>
                {Math.abs(goalDiff).toFixed(1)} kg {goalDiff <= 0 ? "to maintain" : "to lose"}
              </span>
            </div>
          )}
          {profile.health_goal && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
              <p className="text-sm text-slate-600 dark:text-slate-300">{profile.health_goal}</p>
            </div>
          )}
          {!profile.target_weight && !profile.health_goal && (
            <p className="text-sm text-slate-400">No goals set yet. Tap Edit to add one.</p>
          )}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-5 pt-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">{profile ? "Edit Profile" : "Create Profile"}</h1>
        {profile && (
          <button
            onClick={() => setEditing(false)}
            className="text-sm text-slate-400 hover:text-slate-600"
          >
            Cancel
          </button>
        )}
      </div>

      <div className="glass-card rounded-2xl p-5 border border-white/20 space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
            <User className="w-4 h-4" /> Full Name
          </label>
          <input
            type="text"
            value={form.full_name}
            onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            placeholder="Enter your name"
            className={inputClass}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Calendar className="w-4 h-4" /> Age
            </label>
            <input
              type="number"
              value={form.age}
              onChange={(e) => setForm({ ...form, age: e.target.value })}
              placeholder="Age"
              className={inputClass}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 dark:text-slate-200">Gender</label>
            <select
              value={form.gender}
              onChange={(e) => setForm({ ...form, gender: e.target.value })}
              className={inputClass}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Ruler className="w-4 h-4" /> Height (cm)
            </label>
            <input
              type="number"
              value={form.height}
              onChange={(e) => setForm({ ...form, height: e.target.value })}
              placeholder="cm"
              className={inputClass}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Weight className="w-4 h-4" /> Weight (kg)
            </label>
            <input
              type="number"
              value={form.weight}
              onChange={(e) => setForm({ ...form, weight: e.target.value })}
              placeholder="kg"
              className={inputClass}
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
            <Target className="w-4 h-4" /> Target Weight (kg)
          </label>
          <input
            type="number"
            value={form.target_weight}
            onChange={(e) => setForm({ ...form, target_weight: e.target.value })}
            placeholder="Your goal weight"
            className={inputClass}
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700 dark:text-slate-200">Personal Health Goal</label>
          <textarea
            value={form.health_goal}
            onChange={(e) => setForm({ ...form, health_goal: e.target.value })}
            placeholder="e.g. Lose 5 kg in 3 months with balanced diet and exercise"
            rows={2}
            className={`${inputClass} resize-none`}
          />
        </div>
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="w-full py-4 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-200/40 hover:shadow-xl hover:scale-[1.02] transition-all duration-200 disabled:opacity-70 flex items-center justify-center gap-2"
      >
        {saving ? (
          "Saving..."
        ) : (
          <>
            <Save className="w-5 h-5" /> Save Profile
          </>
        )}
      </button>
    </div>
  );
}