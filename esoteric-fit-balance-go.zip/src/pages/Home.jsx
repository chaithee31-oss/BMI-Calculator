import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Calculator, HeartPulse, Activity, Sparkles, ChevronRight, TrendingUp } from "lucide-react";
import { getDailyTip } from "@/lib/bmiUtils";

export default function Home() {
  const dailyTip = useMemo(() => getDailyTip(), []);

  return (
    <div className="space-y-6 pt-8">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center space-y-3"
      >
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-teal-400 via-emerald-400 to-cyan-500 shadow-lg shadow-emerald-200/50 mb-2">
          <HeartPulse className="w-10 h-10 text-white" strokeWidth={2.5} />
        </div>
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">
          FitBalance
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 px-6">
          Understand your body. Improve your health.
        </p>
      </motion.div>

      {/* Illustration card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-500 via-emerald-500 to-cyan-500 p-6 shadow-xl shadow-emerald-200/40"
      >
        <div className="absolute -top-8 -right-8 w-32 h-32 bg-white/10 rounded-full" />
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-white/10 rounded-full" />
        <div className="relative space-y-4">
          <div className="flex items-center gap-2 text-white/90">
            <Sparkles className="w-4 h-4" />
            <span className="text-xs font-semibold uppercase tracking-wider">Your Wellness Journey</span>
          </div>
          <h2 className="text-2xl font-bold text-white leading-tight">
            Know your BMI.<br />Take control of your health.
          </h2>
          <Link
            to="/calculator"
            className="inline-flex items-center gap-2 px-6 py-3.5 bg-white text-emerald-600 rounded-2xl font-semibold text-sm shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200"
          >
            <Calculator className="w-5 h-5" />
            Calculate BMI
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </motion.div>

      {/* Quick stats row */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="grid grid-cols-2 gap-3"
      >
        <Link
          to="/dashboard"
          className="glass-card rounded-2xl p-4 border border-white/20 hover:scale-[1.02] transition-transform"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center mb-2">
            <TrendingUp className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Dashboard</p>
          <p className="text-xs text-slate-400">Track progress</p>
        </Link>
        <Link
          to="/tips"
          className="glass-card rounded-2xl p-4 border border-white/20 hover:scale-[1.02] transition-transform"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center mb-2">
            <Activity className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Health Tips</p>
          <p className="text-xs text-slate-400">Daily wellness</p>
        </Link>
      </motion.div>

      {/* Daily Tip */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="glass-card rounded-2xl p-5 border border-white/20 space-y-3"
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <h3 className="font-semibold text-slate-700 dark:text-slate-200 text-sm">Daily Health Tip</h3>
          <span className="ml-auto text-[10px] font-medium px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
            {dailyTip.category}
          </span>
        </div>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{dailyTip.text}</p>
      </motion.div>

      {/* BMI Categories preview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="space-y-2.5"
      >
        <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-200 px-1">BMI Categories</h3>
        {[
          { label: "Underweight", range: "Below 18.5", color: "bg-sky-400" },
          { label: "Normal Weight", range: "18.5 – 24.9", color: "bg-emerald-400" },
          { label: "Overweight", range: "25 – 29.9", color: "bg-amber-400" },
          { label: "Obesity", range: "30.0 and above", color: "bg-rose-400" },
        ].map((cat) => (
          <div key={cat.label} className="glass-card rounded-xl p-3 border border-white/20 flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${cat.color}`} />
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200 flex-1">{cat.label}</span>
            <span className="text-xs text-slate-400">{cat.range}</span>
          </div>
        ))}
      </motion.div>
    </div>
  );
}